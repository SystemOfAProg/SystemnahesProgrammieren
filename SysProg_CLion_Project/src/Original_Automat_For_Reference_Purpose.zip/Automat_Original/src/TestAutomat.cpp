#include "Automat.h"

int main (int argc, char* argv[]){

	Automat* automat;
	automat = new Automat();

}
